# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class Openc2WebConfig(AppConfig):
    name = 'openC2_web'
